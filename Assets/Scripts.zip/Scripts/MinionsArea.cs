using System.Collections.Generic;
using Unity.MLAgents;
using UnityEngine;
using TMPro;
using Sirenix.OdinInspector;

public class MinionsArea : MonoBehaviour
{
    public PlayerAgent playerAgent;
    public List<GameObject> minions;
    public List<GameObject> flags;
    public TextMeshPro cumulativeRewardText;

    private List<Vector3> originalFlagPositions = new List<Vector3>();
    private List<Quaternion> originalFlagRotations = new List<Quaternion>();

    private List<Vector3> originalMinionPositions = new List<Vector3>();
    private List<Quaternion> originalMinionRotations = new List<Quaternion>();

    void Start()
    {
        // Store original positions for flags
        foreach (var flag in flags)
        {
            originalFlagPositions.Add(flag.transform.position);
            originalFlagRotations.Add(flag.transform.rotation);
        }

        // Store original positions for minions
        foreach (var minion in minions)
        {
            originalMinionPositions.Add(minion.transform.position);
            originalMinionRotations.Add(minion.transform.rotation);
        }
    }

    public void ResetArea()
    {
        RestoreAllFlags();
        RestoreAllMinions();
    }

    // Remove flag by destroying it & setting null in list
    public void RemoveSpecificFlag(int index)
    {
        if (index < 0 || index >= flags.Count) return;
        if (flags[index] != null)
        {
            Destroy(flags[index]);
            flags[index] = null; // Keep index for respawn
        }
    }

    // Respawn flag at original position
    public void RespawnSpecificFlag(int index)
    {
        if (index < 0 || index >= originalFlagPositions.Count) return;

        if (flags[index] == null) // Only respawn if destroyed
        {
            GameObject flagPrefab = Resources.Load<GameObject>("Flag"); 
            // You need to have a prefab named "Flag" inside a Resources folder

            GameObject newFlag = Instantiate(flagPrefab, originalFlagPositions[index], originalFlagRotations[index]);
            flags[index] = newFlag;
        }
        else
        {
            // If it already exists, just reset its position
            flags[index].transform.SetPositionAndRotation(originalFlagPositions[index], originalFlagRotations[index]);
        }
    }

    private void RestoreAllFlags()
    {
        for (int i = 0; i < flags.Count; i++)
        {
            if (flags[i] != null)
                flags[i].transform.SetPositionAndRotation(originalFlagPositions[i], originalFlagRotations[i]);
        }
    }

    private void RestoreAllMinions()
    {
        for (int i = 0; i < minions.Count; i++)
        {
            minions[i].transform.SetPositionAndRotation(originalMinionPositions[i], originalMinionRotations[i]);
        }
    }
}