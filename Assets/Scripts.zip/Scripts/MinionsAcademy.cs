using UnityEngine;
using System.Collections;
using Unity.MLAgents;
public class PlayerAcademy : Unity.MLAgents.Academy
{
    private MinionsArea[] minionsArea;
    
    // Update is called once per frame
    public override void AcademyReset()
    {
        
    }
}
